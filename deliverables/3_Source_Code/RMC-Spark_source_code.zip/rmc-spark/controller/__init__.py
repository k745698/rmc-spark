"""RMC-Spark resilience controller."""
