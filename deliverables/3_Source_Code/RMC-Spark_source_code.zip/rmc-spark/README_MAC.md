# RMC-Spark: minimum run on macOS

These steps run the **minimum experiment** only: 4 systems × ETL workload × 3 faults × 3 reps = 36 runs.
It takes about 1.5 to 2 hours. The full documentation is in [README.md](README.md).

## 1. Requirements

| Item | Needed |
|---|---|
| macOS (Intel or Apple Silicon) | 16 GB RAM recommended |
| [Docker Desktop for Mac](https://www.docker.com/products/docker-desktop/) | installed and **running** |
| Free disk space | about 6 GB |
| Internet | first build only (about 1.5 GB download) |

## 2. Give Docker 12 GB of RAM

Open Docker Desktop, go to **Settings → Resources**, and set:
- **Memory:** 12 GB
- **CPUs:** 6 or more

Click **Apply & Restart**.

## 3. Build (first time only)

```bash
cd rmc-spark
docker compose build
```

## 4. Run the minimum experiment

```bash
bash scripts/run_minimum.sh 2>&1 | tee results/run_minimum_log.txt
```

The script works through these steps:
1. Starts the testbed: 2 Spark clusters, MinIO, Prometheus, Grafana and the controller. It then waits until both clusters report `HEALTHY`.
2. Generates the smaller datasets (1.5 M taxi trips, 1 M graph edges).
3. Calibrates the fault time and deadline from 2 clean runs.
4. Runs the 36-run experiment (about 1.5 h).
5. Produces the tables and figures.

Options:
```bash
bash scripts/run_minimum.sh --skip-data   # datasets already generated
bash scripts/run_minimum.sh --fresh       # delete old results/raw/minimum first
```

While it runs, keep the Mac plugged in. To stop it from sleeping, run the script under `caffeinate`:
```bash
caffeinate -i bash scripts/run_minimum.sh 2>&1 | tee results/run_minimum_log.txt
```

## 5. Results

| Output | Location |
|---|---|
| Raw run data | `results/raw/minimum/runs.csv` |
| Console log | `results/raw/minimum_console.txt` |
| Tables and figures | `results/report/` |

## 6. Optional: watch it live

| UI | URL |
|---|---|
| Spark cluster A | http://localhost:8080 |
| Spark cluster B | http://localhost:8090 |
| Grafana | http://localhost:3000 |
| MinIO | http://localhost:9001 |

Check cluster health:
```bash
docker compose exec controller python -m controller.cli status
```

## 7. Stop

```bash
docker compose down          # stop the containers, keep the data
docker compose down -v       # also delete MinIO data (datasets must then be regenerated)
```

## Troubleshooting

- **`clusters did not become HEALTHY`**: Docker probably has too little memory. Check step 2, then run `docker compose down` and try again.
- **Containers exit with code 137**: they ran out of memory. Raise Docker's memory or close other apps.
- **Port already in use (8080, 3000, 9000…)**: find what is using the port with `lsof -i :8080` and stop it.
- **Run interrupted midway**: rerun with `--skip-data`. Calibration and the experiment will run again.
